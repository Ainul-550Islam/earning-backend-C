# config/settings_localization.py
"""
World #1 Localization System — Production Settings Template.
Copy relevant sections into your main settings.py.
All settings have sensible defaults.
"""

# ── Translation Providers ────────────────────────────────────────
# Uncomment and add your API keys

TRANSLATION_PROVIDERS = {
    'deepl': {
        'enabled': False,  # Set True when you have a key
        'priority': 1,     # Lower = tried first
        'api_key': '',     # Get from https://www.deepl.com/pro-api
        # Free tier keys end in ':fx'
        # Pro tier: 500k chars/month free, then €5.49/1M chars
    },
    'google': {
        'enabled': False,
        'priority': 2,
        'api_key': '',     # Google Cloud Translation API key
        'project_id': '',  # Optional: for v3 API
        # $20/1M chars after 500k free
    },
    'azure': {
        'enabled': False,
        'priority': 3,
        'api_key': '',     # Azure Cognitive Services key
        'region': 'eastus',
        # $10/1M chars
    },
    'amazon': {
        'enabled': False,
        'priority': 4,
        'api_key': '',     # AWS Secret Access Key
        'access_key': '',  # AWS Access Key ID
        'region': 'us-east-1',
        # $15/1M chars
    },
    'openai': {
        'enabled': False,
        'priority': 5,
        'api_key': '',     # OpenAI API key
        'model': 'gpt-4o-mini',  # Recommended: fast + cheap
        'temperature': 0.2,
        # ~$0.15/1M input tokens
        # Use for: rare languages (si, ne, am) and nuanced content
    },
}

# ── GeoIP Settings ───────────────────────────────────────────────
MAXMIND_LICENSE_KEY = ''  # Get free key from https://www.maxmind.com/en/geolite2/signup
GEOIP_PATH = '/var/lib/localization/GeoLite2-City.mmdb'
LOCALIZATION_DETECT_FROM_IP = True

# ── Cache Settings ───────────────────────────────────────────────
# Use Redis for production — much faster than DB cache
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': 'redis://localhost:6379/1',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            'COMPRESSOR': 'django_redis.compressors.zlib.ZlibCompressor',
            'SERIALIZER': 'django_redis.serializers.json.JSONSerializer',
        },
        'KEY_PREFIX': 'loc',
        'TIMEOUT': 3600,
    }
}

# ── Celery Settings ──────────────────────────────────────────────
CELERY_BROKER_URL = 'redis://localhost:6379/0'
CELERY_RESULT_BACKEND = 'redis://localhost:6379/0'
CELERY_ACCEPT_CONTENT = ['json']
CELERY_TASK_SERIALIZER = 'json'
CELERY_RESULT_SERIALIZER = 'json'
CELERY_TIMEZONE = 'UTC'
CELERY_TASK_TRACK_STARTED = True
CELERY_TASK_TIME_LIMIT = 300  # 5 minutes max per task
CELERY_TASK_SOFT_TIME_LIMIT = 240

# ── Celery Beat Schedule ─────────────────────────────────────────
from celery.schedules import crontab

CELERY_BEAT_SCHEDULE = {
    # Exchange rates — every hour
    'update-exchange-rates': {
        'task': 'localization.exchange_rate_tasks.update_rates',
        'schedule': crontab(minute=0),  # Every hour on the hour
        'options': {'expires': 3500},
    },
    # Translation cache cleanup — every 6 hours
    'clean-translation-cache': {
        'task': 'localization.translation_cache_tasks.clean_expired_cache',
        'schedule': crontab(minute=30, hour='*/6'),
    },
    # Rebuild popular translation caches — every 4 hours
    'rebuild-popular-cache': {
        'task': 'localization.translation_cache_tasks.rebuild_popular_cache',
        'schedule': crontab(minute=0, hour='*/4'),
    },
    # Auto-translate missing — nightly at 2am
    'auto-translate-missing': {
        'task': 'localization.auto_translation_tasks.auto_translate_missing',
        'schedule': crontab(minute=0, hour=2),
        'kwargs': {'limit': 200},
    },
    # Translation QA check — nightly at 3am
    'translation-qa-check': {
        'task': 'localization.translation_qa_tasks.run_qa_check',
        'schedule': crontab(minute=0, hour=3),
    },
    # Coverage report — daily at 4am
    'update-coverage': {
        'task': 'localization.coverage_report_tasks.update_coverage',
        'schedule': crontab(minute=0, hour=4),
    },
    # Missing translation alerts — every 2 hours
    'alert-missing-translations': {
        'task': 'localization.missing_translation_tasks.alert_missing_translations',
        'schedule': crontab(minute=0, hour='*/2'),
    },
    # Daily analytics aggregation — at midnight
    'aggregate-daily-insights': {
        'task': 'localization.insight_tasks.aggregate_daily_insights',
        'schedule': crontab(minute=0, hour=0),
    },
    # General cleanup — weekly Sunday at 5am
    'cleanup-all': {
        'task': 'localization.cleanup_tasks.cleanup_all',
        'schedule': crontab(minute=0, hour=5, day_of_week=0),
    },
    # GeoIP database update — weekly Sunday at 6am
    'update-geoip-db': {
        'task': 'localization.geoip_update_tasks.update_geoip_db',
        'schedule': crontab(minute=0, hour=6, day_of_week=0),
    },
    # Provider health check — every 30 minutes
    'check-provider-health': {
        'task': 'localization.provider_health_tasks.check_provider_health',
        'schedule': crontab(minute='*/30'),
    },
    # TM index from translations — weekly
    'index-translation-memory': {
        'task': 'localization.translation_memory_tasks.index_approved_translations',
        'schedule': crontab(minute=0, hour=7, day_of_week=1),
    },
    # Build language packs — daily at 5am
    'build-language-packs': {
        'task': 'localization.language_pack_tasks.build_all_packs',
        'schedule': crontab(minute=0, hour=5),
    },
}

# ── Localization App Settings ────────────────────────────────────
LOCALIZATION_ALERT_EMAIL = True  # Send email alerts on high missing translation count
LOG_MISSING_TRANSLATIONS = True
USER_PREF_CACHE_TTL = 3600
API_CACHE_TIMEOUT = 3600
CACHE_24_HOURS = 86400
MAX_TRANSLATION_TEXT_LENGTH = 5000
LANGUAGE_PACK_CDN_URL = '/api/localization/public/translations'

# ── Middleware ───────────────────────────────────────────────────
# Add to MIDDLEWARE in correct order:
# LOCALIZATION_MIDDLEWARE = [
#     'api.localization.middleware.TimezoneMiddleware',
#     'api.localization.middleware.CurrencyMiddleware',
#     'api.localization.middleware.TranslationMiddleware',
#     'api.localization.middleware.DeviceDetectionMiddleware',
# ]

# ── Database Indexes (PostgreSQL) ────────────────────────────────
# Run migration 0008_performance_indexes.py to add these:
# - GIN index on translation.value for full-text search
# - B-tree composite on (language_id, is_approved, created_at)
# - Hash index on translation_memory.source_hash

# ── API Keys for other services ──────────────────────────────────
LOCALIZATION_API_KEYS = [
    # Add server-to-server API keys here
    # 'your-internal-api-key-here',
]

# ── Rate Limiting ────────────────────────────────────────────────
LOCALIZATION_RATE_LIMITS = {
    'translate': '100/hour',
    'public_translations': '1000/hour',
    'currency_convert': '500/hour',
    'geoip': '200/hour',
}
