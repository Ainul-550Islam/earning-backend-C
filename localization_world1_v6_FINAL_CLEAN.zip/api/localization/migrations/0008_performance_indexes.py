# migrations/0008_performance_indexes.py
"""
Performance indexes for World #1 localization system.
PostgreSQL-optimized for high-throughput translation lookups.

Run: python manage.py migrate localization 0008
"""
from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('localization', '0007_config_formats')]

    operations = [
        # ── Translation table — most-queried ──────────────────────
        # Composite: language + approved + created (for coverage queries)
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_translation_lang_approved
            ON localization_translation (language_id, is_approved, created_at DESC);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_translation_lang_approved;"
        ),
        # Key + language lookup (most common pattern)
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_translation_key_lang
            ON localization_translation (key_id, language_id);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_translation_key_lang;"
        ),

        # ── Translation Memory — fuzzy search ─────────────────────
        # Hash lookup (exact match — O(1))
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_tm_hash_langs
            ON localization_translationmemory (source_hash, source_language_id, target_language_id);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_tm_hash_langs;"
        ),
        # Fuzzy candidate filtering by word count + language pair
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_tm_lang_pair_wordcount
            ON localization_translationmemory (source_language_id, target_language_id, source_word_count);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_tm_lang_pair_wordcount;"
        ),
        # Usage-based ordering for TM suggestions
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_tm_usage
            ON localization_translationmemory (usage_count DESC, is_approved);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_tm_usage;"
        ),

        # ── Missing Translation — alert queries ───────────────────
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_missing_lang_resolved
            ON localization_missingtranslation (language_id, resolved, created_at DESC);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_missing_lang_resolved;"
        ),

        # ── TranslationKey — category/namespace filtering ─────────
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_key_category_namespace
            ON localization_translationkey (category, namespace);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_key_category_namespace;"
        ),

        # ── Exchange Rate — rate lookup ───────────────────────────
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_exrate_pair_date
            ON localization_exchangerate (from_currency_id, to_currency_id, date DESC);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_exrate_pair_date;"
        ),

        # ── Localization Insight — analytics queries ──────────────
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_insight_date_lang
            ON localization_localizationinsight (date DESC, language_id);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_insight_date_lang;"
        ),

        # ── GeoIP Mapping — range lookup ─────────────────────────
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_geoip_range
            ON localization_geoipmapping (ip_start_int, ip_end_int);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_geoip_range;"
        ),

        # ── LocalizedContent — content type + object lookup ──────
        migrations.RunSQL(
            sql="""
            CREATE INDEX IF NOT EXISTS idx_localized_content_lookup
            ON localization_localizedcontent (content_type, object_id, language_id);
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_localized_content_lookup;"
        ),

        # ── Full-text search on translation value (PostgreSQL only) ─
        # This enables: Translation.objects.filter(value__search='hello')
        migrations.RunSQL(
            sql="""
            DO $$ BEGIN
              IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_trgm') THEN
                CREATE INDEX IF NOT EXISTS idx_translation_value_trgm
                ON localization_translation USING gin (value gin_trgm_ops);
              END IF;
            END $$;
            """,
            reverse_sql="DROP INDEX IF EXISTS idx_translation_value_trgm;"
        ),
    ]
